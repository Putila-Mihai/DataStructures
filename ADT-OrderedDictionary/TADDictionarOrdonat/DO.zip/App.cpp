#include <iostream>
//TAD Dicționar Ordonat – reprezentare sub forma unui ABC reprezentat înlănțuit, cu înlănțuiri
//reprezentate pe tablou.
#include "TestScurt.h"
#include "TestExtins.h"
int main(){
    testAll();
    testAllExtins();
    std::cout<<"Finished Tests!"<<std::endl;


}